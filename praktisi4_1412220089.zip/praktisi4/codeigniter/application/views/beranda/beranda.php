<div class="jumbotron mb-5">  
 <h1>Welcome to Our Website!</h1>  
 <p class="mb-5">This is the home page of our website.</p>  </div>