<main>
        <section class="intro">
            <h2>Pengenalan</h2>
            <h5>Hallo yang ada di sana, Saya <b>I Love Shollakhuddin Kurniawan</b> atau bisa dipanggil <b>Luvi</b></h5>
            <h5>Saya adalah mahasiswa dari Universitas PGRI Ronggolawe Tuban yang berminat untuk menjadi fullstack web developer,
              Saya tinggal di provinsi jawa timur, Kabupaten Lamongan, Kecamatan Brondong, Desa Brengkok, Dusun Pambon,
              Saat ini saya berusia 19 tahun dan sedang mengerjakan beberapa proyek web
            </h5>
            <br>
            <h5>Anda juga dapat mengunjungi github saya di <a href="https://github.com/lluuvvii">github.com/lluuvvii</a></h5>
        </section>

        <section class="content">
            <?php
            // Menggunakan PHP untuk menampilkan tanggal dan waktu saat ini
            echo "<p>Hari ini: " . date("l, d F Y") . "</p>";
            ?>
        </section>
    </main>