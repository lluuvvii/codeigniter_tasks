<div class="container mt-5">
    <div class="card">
        <div class="card-body">
            <table class="table table-hover">
                <thead class="blue-grey lighten-4">
                    <tr>
                        <th>ID Barang</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Kategori Barang</th>
                        <th>Deskripsi Barang</th>
                        <th>Harga Beli</th>
                        <th>Harga Jual</th>
                        <th>Stok Barang</th>
                        <th>Supplier Barang</th>
                        <th>Tanggal Masuk</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($barang as $item): ?>
                      <tr>
                          <td><?php echo $item->id_barang; ?></td>
                          <td><?php echo $item->kode_barang; ?></td>
                          <td><?php echo $item->nama_barang; ?></td>
                          <td><?php echo $item->kategori_barang; ?></td>
                          <td><?php echo $item->deskripsi_barang; ?></td>
                          <td><?php echo $item->harga_beli; ?></td>
                          <td><?php echo $item->harga_jual; ?></td>
                          <td><?php echo $item->stok_barang; ?></td>
                          <td><?php echo $item->supplier_barang; ?></td>
                          <td><?php echo $item->tanggal_masuk; ?></td>
                      </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>