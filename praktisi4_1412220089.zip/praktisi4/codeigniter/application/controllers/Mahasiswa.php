<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Mahasiswa extends CI_Controller
{
  public function __construct()
  {
    // parent::__construct();
    // $this->load->model('Mahasiswa_model'); // Memuat model Mahasiswa_model
    parent::__construct();
    $this->load->helper('url'); // Memuat URL Helper
    $this->load->model('Mahasiswa_model'); // Memuat model Mahasiswa_model
  }
  public function index()
  {
    $data['mahasiswa'] = $this->Mahasiswa_model->get_mahasiswa(); // Mendapatkan data mahasiswa dari model
    $keyword = $this->input->get('keyword');
    $criteria = $this->input->get('criteria'); // Tambahkan ini untuk mendapatkan kriteria pencarian dari form

    if ($keyword != '') {
      $data['mahasiswa'] = $this->Mahasiswa_model->search_mahasiswa($keyword, $criteria);
    }

    $this->load->view('mahasiswa_view', $data); // Menampilkan data mahasiswa ke view
  }

  public function input_data()
  {
    $this->load->view('input_data');
  }
  public function tampilkan_data()
  {
    $this->form_validation->set_rules(
      'nama',
      'Nama',
      'required'
    );
    $this->form_validation->set_rules(
      'npm',
      'NPM',
      'required|numeric', // Validasi agar hanya angka yang diterima
      array(
        'numeric' => 'Kolom {field} hanya boleh berisi angka.'
      )
    );
    $this->form_validation->set_rules(
      'angkatan',
      'Angkatan',
      'required|regex_match[/^\d{4}$/]', // Validasi agar format tahun (4 digit)
      array(
        'regex_match' => 'Format {field} harus berupa 4 digit tahun.'
      )
    );
    $this->form_validation->set_rules(
      'kelas',
      'Kelas',
      'required|regex_match[/^[A-Z]{1}$/]', // Validasi format 1 huruf dan huruf besar
      array(
        'regex_match' => 'Kolom {field} hanya boleh berisi 1 huruf besar.'
      )
    );
    $this->form_validation->set_rules(
      'alamat',
      'Alamat',
      'required|min_length[20]', // Validasi minimal 20 karakter
      array(
        'min_length' => 'Kolom {field} minimal harus mengandung 20 karakter.'
      )
    );
    $this->form_validation->set_rules('mata_kuliah', 'Mata
Kuliah Favorit', 'required');
    $this->form_validation->set_message('required', 'Kolom {field} harus diisi.');
    // Jalankan validasi
    if ($this->form_validation->run() == false) {
      // Jika validasi gagal, tampilkan kembali form input data
      $this->load->view('input_data');
    } else {

      // Ambil data dari form jika validasi berhasil
      $data['nama'] = $this->input->post('nama');
      $data['npm'] = $this->input->post('npm');
      $data['angkatan'] = $this->input->post('angkatan');
      $data['kelas'] = $this->input->post('kelas');
      $data['alamat'] = $this->input->post('alamat');
      $data['mata_kuliah'] = $this->input->post('mata_kuliah');
      // Tampilkan data di halaman lain
      $this->load->view('hasil_data', $data);
    }
  }
  public function search()
  {
    // $keyword = $this->input->post('keyword'); // Ambil kata kunci pencarian dari form
    // $data['mahasiswa'] = $this->Mahasiswa_model->search_mahasiswa($keyword); // Cari mahasiswa berdasarkan nama
    // $this->load->view('mahasiswa_view', $data); // Menampilkan hasil pencarian ke view
    //<select name="criteria">
    //<option value="nama">Nama</option>
    //<option value="npm">NPM</option>
    //<option value="angkatan">Angkatan</option>
    //    <option value="kelas">Kelas</option>
    //    <option value="alamat">Alamat</option>
    //    <option value="mata_kuliah_favorit">Mata Kuliah Favorit</option>
    //</select>
    //
  }

  public function data_mahasiswa()
  {
    $data['title'] = 'Data Mahasiwa';
    $data['active_menu'] = 'data_mahasiswa';
    $data['mahasiswa'] = $this->Mahasiswa_model->get_all_mahasiswa();
    $data['content'] = $this->load->view('mahasiswa/list_mahasiswa', $data, true);
    $this->load->view('template/template', $data);
  }
  public function search_mahasiswa()
  {
    $keyword = $this->input->post('keyword');
    $data['title'] = 'Data Mahasiwa';
    $data['active_menu'] = 'data_mahasiswa';
    $data['mahasiswa'] = $this->Mahasiswa_model->search_data_mahasiswa($keyword);
    $data['keyword'] = $keyword;
    $data['content'] = $this->load->view('mahasiswa/list_mahasiswa', $data, true);
    $this->load->view('template/template', $data);
  }

  public function tentang()
  {
    $data['title'] = 'About Page';
    $data['active_menu'] = 'tentang';
    $data['content'] = $this->load->view('tentang/tentang', '', true);
    $this->load->view('template/template', $data);
  }
}