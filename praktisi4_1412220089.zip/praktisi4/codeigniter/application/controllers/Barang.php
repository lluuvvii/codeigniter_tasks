<?php
class Barang extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_model');
    }

    public function index()
    {
        $data['barang'] = $this->Barang_model->get_all_barang();
        // $this->load->view('barang_view', $data);
        $data['title'] = 'Product Page';
        $data['active_menu'] = 'barang';
        $data['content'] = $this->load->view('barang_view', $data, true);
        $this->load->view('template/template', $data);
    }
}
